function youtube_parser(url) {
  var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
  var match = url.match(regExp);
  return (match && match[7].length == 11) ? match[7] : false;
}

let enabled;

function checkUrl(url) {
  getStoredStatus(enabled => {
    if (youtube_parser(url) !== false && enabled) {
      chrome.tabs.create({
        url: 'rykentube:Video?ID=' + youtube_parser(url),
      }, function(tab) {
        setTimeout(() => {
          chrome.tabs.remove(tab.id);
        }, 500); 
      });
    }
  })
}

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo && changeInfo.status == "loading" && changeInfo.url && youtube_parser(changeInfo.url) !== false && enabled) {
    if (confirm('Open in myTube?')) {
      checkUrl(changeInfo.url);
      chrome.tabs.sendMessage(tabId, { data: tab }, function(response) {

      });
    }
  }
});

var filter = {
  url:
    [
      { hostContains: "youtube" }
    ]
}

function setStoredStatus(status) {
  if (chrome && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ enabled: status });
  } else {
    console.error('Cannot access storage API. State cannot be saved');
  }
}

function getStoredStatus(cb) {
  chrome.storage.local.get(["enabled"], result => {
    if(result.enabled == undefined) setStoredStatus(true)
    cb(result.enabled);
  })
}

chrome.browserAction.onClicked.addListener(function(tab) {
  setStoredStatus(!enabled);
  enabled = !enabled;
  alert((enabled ? 'Enabled' : 'Disabled') + ' myTube integration');
  chrome.tabs.sendMessage(tab.id, { enabled: !enabled }, function(response) {

  });
});

chrome.webNavigation.onBeforeNavigate.addListener((result) => {
  getStoredStatus(enabled => {
    if (enabled && confirm('Open in myTube?')) {
      checkUrl(result.url);
      chrome.tabs.sendMessage(result.tabId, { data: result }, function(response) {

      });
    }
  })
}, filter);

getStoredStatus(result => {
  enabled = result;
}); 