function setStoredStatus(status) {
    if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ enabled: status });
    } else {
        console.error('Cannot access storage API. State cannot be saved');
    }
}

function getStoredStatus(cb) {
    browser.storage.local.get(["enabled"])
        .then(result => {
            if (result.enabled == undefined) setStoredStatus(true);
            cb(result.enabled);
        })
}

getStoredStatus(result => {
    document.getElementById('status').innerText = (result ? 'enabled ' : 'disabled');
    if (result) {
        document.getElementById('onoff').checked = true;
    }
});


document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('onoff').addEventListener('change', () => {
        chrome.runtime.sendMessage({ changeState: document.getElementById('onoff').checked });
        document.getElementById('status').innerText = (document.getElementById('onoff').checked ? 'enabled ' : 'disabled');
    });
});


